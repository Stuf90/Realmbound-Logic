# Murdoku Logic Engine

Asset-agnostic core logic for Murdoku-style spatial deduction puzzles: rules,
a puzzle generator, and a solver, all working on placeholder ids only (no
character names, no art, no tile graphics). A consuming project supplies its
own suspects, room fiction, and prop art on top of a `MurdokuDefinition`.

## What is Murdoku?

A grid placement puzzle: every suspect occupies exactly one row and one
column (like a permutation matrix), rooms group cells into named areas,
clues are structured rules (not free text), and — once the board is
solved — the murderer is whoever else ends up alone with the victim in the
victim's room. The victim's own cell is never stated by a clue; it's forced
by elimination.

### Board rules

- **One suspect per row, one per column.** The board is a permutation
  matrix, not a free grid — this is what makes row/column-only clues
  (`exact-row`, `exact-column`) meaningful and makes a suspect-pair
  "beside"/"not beside" clue always vacuous (see below).
- **Rooms** group cells into named areas; **areas** (optional, via
  `Cell.areaId`) subdivide a room further for finer-grained occupant-count
  clues. Every room must have at least one occupant in the authored
  solution (`validateDefinition` enforces this).
- **Cells can be blocked** (no suspect may ever occupy them) and may carry a
  **prop** — `seat` (occupiable; a blocked seat is invalid) or `decorative`
  (always blocked; decoration can't be sat on).
- **Clues are binding rules, not hints** — every clue in `Clue[]` must hold
  in the authored `solution`, and the full clue set must pin down that
  solution uniquely (`validateDefinition` re-runs the solver to check this).
- **The victim's cell is never named by any clue.** It's the one position
  forced purely by process of elimination once everyone else is placed.
- **Murderer rule.** Once solved, look at who else occupies the victim's
  room. Exactly one other suspect must — that's the murderer. Two people in
  a room together counts as "alone with each other"; three or more does
  not, so a valid puzzle's victim room always has exactly two occupants.

### The swap hazard (why every suspect needs exactly one valid cell)

A puzzle isn't "clear" just because every individual clue reads
unambiguously — two suspects can each satisfy every clue that mentions them
and still be *interchangeable* with each other, if nothing in the clue set
tells them apart. Concretely: if suspect A and suspect B are only ever
constrained by "A is in the kitchen" and "B is in the kitchen," and the
kitchen has two open cells, either could take either cell and every stated
clue still holds. A player has no way to know which is correct — the puzzle
reads as solved but isn't uniquely so. (This is the exact bug class that
shipped in Realmbound Logic's Royal Inquest level 7, where the miller and
the reeve could trade cells and both placements satisfied every given
hint.)

`solve()` (`src/solver.ts`) exists precisely to catch this: it doesn't stop
at "some assignment satisfies the clues," it keeps searching for a *second*
one and reports `"multiple"` the moment it finds it — a swap like the one
above is caught the same way as any other under-constrained board.
`validateDefinition` re-runs `solve()` and fails the definition if status
isn't `"unique"`. Concretely, this means: **every suspect must end up with
exactly one cell it can legally occupy, across every valid assignment —
not merely "a" cell that happens to work.** See
`test/solver.test.ts` / `test/validation.test.ts` ("the swap hazard") for a
worked minimal repro.

This matters most for **hand-authored** puzzles (a consuming project
writing its own clue set instead of calling `generatePuzzle`): nothing
stops an author from writing a clue set that "feels" complete but is
actually swap-ambiguous. **Always run `validateDefinition` on a
hand-authored `MurdokuDefinition` before shipping it** — it's the only
mechanical guarantee against this hazard, authorial confidence isn't
enough. `generatePuzzle` already does this by construction (see below), but
consuming projects skipping the generator in favor of their own hand-built
cases get no such guarantee for free.

### Clue vocabulary

Each predicate below is a single atomic rule; clues compose additively — a
phrase like "the *only* person beside the plant" isn't its own predicate
type, it's `near-prop` (this suspect is beside it) plus `prop-neighbor-count`
pinned to exactly 1 (nobody else is). Difficulty tier (1–3) is the minimum
puzzle difficulty a clue of that type may appear in — see
`src/predicateDifficulty.ts`.

| Predicate | Tier | Natural-language shape |
|---|---|---|
| `exact-row` | 1 | "X is in row 3" (row 0 = top; also how you author "X is in the top/bottom row") |
| `exact-column` | 1 | "X is in column 2" (also "leftmost/rightmost column") |
| `exact-room` | 1 | "X is in the kitchen" |
| `same-room` / `different-room` | 1 | "X and Y are in the same/different room" |
| `on-prop` | 1 | "X is on the couch" (a prop occupies one cell, so this is inherently exclusive — no second predicate needed for "the only person on it") |
| `prop-in-room` | 1 | "There is a plant in the library" — a static board fact, names no suspect (see below) |
| `not-on-prop` | 1 | "X is not on the couch" |
| `not-seated` | 1 | "X is not seated" (their cell has no prop, or the prop isn't a `seat`) |
| `not-exact-room` | 1 | "X is not in the kitchen" |
| `seated-suspect-count` | 1 | "Exactly 2 people are seated" / "at least 2 people are seated" |
| `direction-from` | 2 | "X is south of Y" (8-way: N/S/E/W plus NE/NW/SE/SW). Per the fan glossary, cardinal directions are a loose single-axis comparison — "south of" is "strictly below, any column" — not axis-locked; requiring a shared row/column (the initial, incorrect reading) would make every cardinal clue vacuous on this one-per-row/column permutation board, since two distinct suspects never share an axis. Diagonals (NE/NW/SE/SW) require both axes to differ in the stated direction, same as before. |
| `room-occupant-count` | 2 | "X shares their room with exactly 1 other person" (count excludes X itself) |
| `area-occupant-count` | 2 | Same as above, scoped to a finer-grained area within the room |
| `in-corner` | 2 | "X is in a corner of the board" |
| `not-in-corner` | 2 | "X is not in a corner of the board" |
| `not-beside-wall` | 2 | "X is not against a wall" (every orthogonal neighbor cell shares X's room) |
| `beside-wall` | 2 | "X is against a wall" — exact negation of `not-beside-wall`: at least one orthogonal neighbor is off-board or in another room |
| `category-on-prop` | 2 | "A [category] sat in the armchair" — whoever occupies the prop's cell belongs to that category; names no suspect, so it works for the unnamed "a man was in it" clue shape |
| `near-prop` | 2 | "X is beside the plant" — orthogonal adjacency **and same room as the prop**; a cell that merely touches the prop's cell across a room boundary doesn't count |
| `not-near-prop` | 2 | "X is not beside the plant" — negation of `near-prop`, with the same same-region scoping |
| `axis-offset-from` | 2 | "X is exactly one row south of Y" (pins one axis, ignores the other) |
| `shares-prop-neighbor` | 2 | "X is beside the plant, and so is someone else" |
| `category-room-count` | 2 | "Exactly 2 [category] are in the kitchen" (counts by `Suspect.category`, scoped to one room) |
| `beside-empty-cell` | 2 | "There is an empty seat/space beside X" — at least one of X's orthogonal same-room unblocked cells ends up unoccupied |
| `prop-in-axis` | 2 | "There is a window somewhere in X's row/column" (X's own cell doesn't count) |
| `shares-prop-category-neighbor` | 2 | "X and Y are each beside a plant" — both beside *some* prop sharing a `Prop.category`, not necessarily the same prop |
| `room-rank` | 2 | "X is the southmost/northmost/westmost/eastmost person in the kitchen" — X is the topmost/bottommost/leftmost/rightmost of that room's occupants by row or column |
| `category-not-beside-prop` | 3 | "No [category] is beside the window" |
| `diagonal-from` / `not-diagonal-from` | 3 | "X is on the same diagonal as Y" — unbounded distance (row delta = column delta, any magnitude), not adjacency-only |
| `offset-from` | 3 | "X is exactly one row south and one column east of Y" (full 2-axis vector) |
| `prop-neighbor-count` | 3 | "Exactly 1 person is beside the plant" — combine with `near-prop` to say "X is the *only* person beside it" |
| `room-order-compare` | 3 | "X is at a later hole than Y" / "X is immediately before Y" — compares the two suspects' rooms by `Room.order` |
| `one-of` | max of its options | "X is in the kitchen **or** the den" — a disjunction over nested predicates |
| `all-of` | max of its options | A conjunction over nested predicates — mainly useful as an option *inside* a `one-of`, for a real clue whose disjunction is between two multi-part alternatives (e.g. "she was in the Kitchen with Dana, or in the Den with Ezra") rather than two single predicates |

Every count predicate (`*-count`) takes a `comparator: "exact" | "at-least"` —
real Murdoku clues include both "exactly N" and "at least N" phrasings.

`one-of` and `all-of` have no fixed tier: each is as hard as its hardest
nested option (recursively — an option may itself be a `one-of` or `all-of`).
Use `effectivePredicateDifficulty(predicate)` rather than the
`PREDICATE_DIFFICULTY` table when rating a concrete clue; `validateDefinition`'s
difficulty gate already does.

`room-order-compare` covers the "immediately before/after [location]"
phrasing — numbered holes on a golf course, numbered stops on a bus route,
courses in a menu. It reads `Room.order`, an optional field a consuming
project must set on every room a `room-order-compare` clue can reach; rooms
without an `order` make the predicate evaluate `"unknown"` forever, which
leaves the puzzle under-constrained rather than wrong.

`prop-in-room` is decided by the board layout alone — it never depends on
placements and never evaluates `"unknown"`. It also names no suspect, so **on
its own it can never pin anything down**; it's only ever half of a real-world
compound clue like "he was in a room with a plant," where the other half (an
`exact-room` naming that same room) does the actual constraining. Use it to
carry the reader-facing half of such a clue, never as a puzzle's only mention
of a room.

**Deliberately not modeled:** a suspect-pair `beside`/`not-beside` predicate —
one-per-row/column makes it always vacuously true or false, a genre-math fact
rather than a missing feature.

## Real-world case library (grounding for sizes and clue variety)

[murdoku.fans/en/cases](https://murdoku.fans/en/cases/) (the same unofficial
fan guide the predicate vocabulary is cross-checked against) catalogs 57
official Murdoku cases across five difficulty tiers. Useful facts pulled
from that list for grounding generator inputs and reviewing hand-authored
puzzles:

| Tier | Case count | Grid sizes seen |
|---|---|---|
| Very Easy | 8 | 5×5 – 7×7 |
| Easy | 14 | 5×5 – 9×9 |
| Medium | 12 | 8×8 – 12×12 |
| Hard | 17 | 9×9 – 13×13, plus non-square boards |
| Expert | 6 | 12×12 – 16×16 |

Most cases are square, but **non-square boards are canon, not an edge
case**: official Hard-tier cases include River Crossing (9×10), Swimming
with the Fishes (11×9), and The Hiking Trip (12×14). This engine's
auto-generated layout (`autoBoardLayout` in `src/generator.ts`) requires a
square permutation board (see "Board rules" above), but a caller-supplied
`board` is not so constrained — pass a non-square `board` with sufficiently
granular rooms to match what real cases actually ship, rather than
defaulting to square out of habit.

When asked to produce or review a puzzle "like a real Murdoku case," prefer
sizes and difficulty pairings drawn from this table over arbitrary ones —
e.g. a "Very Easy" request should land at 5×5–7×7, not 9×9.

## Package layout

- `src/types.ts` — the domain model (`Suspect`, `Room`, `Cell`, `Prop`,
  `MurdokuPredicate`, `MurdokuDefinition`).
- `src/board.ts` — pure grid/room/prop helpers shared by the rest of the
  package.
- `src/predicates.ts` — evaluates every clue predicate against a (possibly
  partial) placement, returning `true | false | 'unknown'`.
- `src/predicateDifficulty.ts` — the 1–3 difficulty tier per predicate type.
- `src/solver.ts` — backtracking solver; proves a clue set has zero, one, or
  multiple valid solutions.
- `src/validation.ts` — validates a `MurdokuDefinition`: board/room/prop
  consistency, the victim-naming ban, the difficulty gate, and (via the
  solver) that the clue set is satisfiable, unique, and matches the authored
  solution and murderer.
- `src/generator.ts` — builds a random, unique, minimal-clue
  `MurdokuDefinition` from a seed (optionally around a caller-supplied board
  layout).
- `src/rng.ts` — seeded PRNG so generator runs are reproducible.

## Usage

```ts
import { generatePuzzle, validateDefinition } from "murdoku-logic-engine";

const definition = generatePuzzle({
  rows: 6,
  columns: 6,
  suspectCount: 6,
  difficulty: 2,
  seed: 12345,
});

const { valid, errors } = validateDefinition(definition);
```

Without a caller-supplied `board`, `rows`, `columns`, and `suspectCount` must
all be equal (a full permutation board, one suspect per row **and** column,
none left over). A "spare" row or column beyond `suspectCount` leaves the
victim's coordinate on that axis structurally unresolvable: no legal clue
may ever name the victim, so nothing can pin down which of the leftover
rows/columns is actually theirs. Pass your own `board` with sufficiently
granular rooms if you need a non-square board or spare capacity.

Everything in a generated (or hand-authored) `MurdokuDefinition` uses
placeholder ids (`suspect-1`, `room-0-0`, `chair-1`, ...). A consuming
project maps those ids to its own names, fiction, and art.

## Development

```sh
npm install
npm test    # vitest
npm run build   # tsc --noEmit
```

## CLI: generate a puzzle

```sh
npm run generate -- --rows 6 --columns 6 --suspects 6 --difficulty 2 --seed 12345 [--out puzzle.json]
```

Runs `generatePuzzle` + `validateDefinition` and prints (or writes) the
resulting `MurdokuDefinition` as JSON. See
`.claude/skills/generate-murdoku-puzzle/SKILL.md` for the agent-facing
workflow (retry-on-seed guidance, how to describe results without inventing
fiction).
